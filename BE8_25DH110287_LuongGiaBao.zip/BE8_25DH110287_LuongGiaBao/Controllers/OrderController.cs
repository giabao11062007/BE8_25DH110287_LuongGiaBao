﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using MaSV_MyStore.Models;
using MaSV_MyStore.Models.ViewModel;

namespace MaSV_MyStore.Controllers
{
    public class OrderController : Controller
    {
        private MyStoreEntities db = new MyStoreEntities();

        [Authorize]
        [HttpGet]
        public ActionResult Checkout()
        {
            var cart = Session["Cart"] as List<CartItem>;

            if (cart == null || !cart.Any())
            {
                return RedirectToAction("Index", "Cart");
            }

            var user = db.Users.SingleOrDefault(
                u => u.Username == User.Identity.Name);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var customer = db.Customers.SingleOrDefault(
                c => c.Username == user.Username);

            if (customer == null)
            {
                return RedirectToAction("Index", "Cart");
            }

            var model = new CheckoutVM
            {
                ShippingAddress = customer.Address
            };

            return View(model);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Checkout(CheckoutVM model)
        {
            var cart = Session["Cart"] as List<CartItem>;

            if (cart == null || !cart.Any())
            {
                return RedirectToAction("Index", "Cart");
            }

            var user = db.Users.SingleOrDefault(
                u => u.Username == User.Identity.Name);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var customer = db.Customers.SingleOrDefault(
                c => c.Username == user.Username);

            if (customer == null)
            {
                ModelState.AddModelError("", "Không tìm thấy thông tin khách hàng.");
                return View(model);
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            decimal totalAmount = 0;

            foreach (var item in cart)
            {
                if (item.Quantity <= 0)
                {
                    ModelState.AddModelError("", "Số lượng sản phẩm không hợp lệ.");
                    return View(model);
                }

                totalAmount += Convert.ToDecimal(item.Product.Price) * item.Quantity;
            }

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    var order = new Order
                    {
                        CustomerID = customer.CustomerID,
                        OrderDate = DateTime.Now,
                        TotalAmount = totalAmount,
                        ShippingAddress = model.ShippingAddress,
                        DeliveryMethod = model.DeliveryMethod,
                        PaymentMethod = model.PaymentMethod,
                        PaymentStatus = "Pending",
                        OrderStatus = "Chờ xử lý"
                    };

                    db.Orders.Add(order);
                    db.SaveChanges();

                    foreach (var item in cart)
                    {
                        var detail = new OrderDetail
                        {
                            OrderID = order.OrderID,
                            ProductID = item.Product.ProductID,
                            Quantity = item.Quantity,
                            UnitPrice = Convert.ToDecimal(item.Product.Price)
                        };

                        db.OrderDetails.Add(detail);
                    }

                    db.SaveChanges();
                    transaction.Commit();

                    Session["Cart"] = null;

                    return RedirectToAction("OrderSuccess", new { id = order.OrderID });
                }
                catch
                {
                    transaction.Rollback();
                    ModelState.AddModelError("", "Không thể đặt hàng. Vui lòng thử lại.");
                    return View(model);
                }
            }
        }

        [Authorize]
        public ActionResult OrderSuccess(int id)
        {
            var user = db.Users.SingleOrDefault(
                u => u.Username == User.Identity.Name);

            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var customer = db.Customers.SingleOrDefault(
                c => c.Username == user.Username);

            if (customer == null)
            {
                return RedirectToAction("Index", "Home");
            }

            var order = db.Orders
                .Include("OrderDetails")
                .SingleOrDefault(o =>
                    o.OrderID == id &&
                    o.CustomerID == customer.CustomerID);

            if (order == null)
            {
                return HttpNotFound();
            }

            return View(order);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }

            base.Dispose(disposing);
        }
    }
}
