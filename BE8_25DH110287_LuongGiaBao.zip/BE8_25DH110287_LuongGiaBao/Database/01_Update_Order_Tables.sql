﻿USE MyStore;
GO

IF COL_LENGTH('dbo.[Order]', 'DeliveryMethod') IS NULL
    ALTER TABLE dbo.[Order] ADD DeliveryMethod NVARCHAR(50) NULL;
GO

IF COL_LENGTH('dbo.[Order]', 'PaymentMethod') IS NULL
    ALTER TABLE dbo.[Order] ADD PaymentMethod NVARCHAR(50) NULL;
GO

IF COL_LENGTH('dbo.[Order]', 'ShippingAddress') IS NULL
   AND COL_LENGTH('dbo.[Order]', 'AddressDelivery') IS NOT NULL
    EXEC sp_rename 'dbo.[Order].AddressDelivery', 'ShippingAddress', 'COLUMN';
GO

IF COL_LENGTH('dbo.OrderDetail', 'TotalPrice') IS NULL
    ALTER TABLE dbo.OrderDetail
    ADD TotalPrice AS (Quantity * UnitPrice) PERSISTED;
GO
