﻿BAI WEB BE DEVELOPMENT - PART 3 CUSTOMER SITE
Ten goi: BE8_25DH110287_LuongGiaBao

Cac file trong goi:
- Database/01_Update_Order_Tables.sql
- Models/ViewModel/CheckoutVM.cs
- Controllers/OrderController.cs
- Views/Order/Checkout.cshtml
- Views/Order/OrderSuccess.cshtml

CACH SU DUNG
1. Sao luu database truoc khi chinh sua.
2. Mo file SQL va kiem tra ten database, ten bang, ten cot truoc khi chay.
3. Trong Visual Studio, copy tung file vao dung thu muc cua project ASP.NET MVC 5 hien co.
4. Thay namespace MaSV_MyStore bang namespace project cua ban neu khac.
5. Doi chieu ten DbContext, cac model va thuoc tinh trong code voi EDMX/database thuc te.
6. Neu dung Entity Framework Database First, chon Update Model from Database sau khi cap nhat database.
7. Build project bang Ctrl+Shift+B va sua cac ten thuoc tinh neu model cua ban khac.
8. Chay website, dang nhap, them san pham vao gio hang, mo Checkout va dat hang.

LUU Y
- Day la bo file ma nguon de ghep vao project MVC 5 co san, khong phai mot project Visual Studio doc lap.
- Code gia dinh DbContext la MyStoreEntities, namespace la MaSV_MyStore va cac thuoc tinh model theo ten trong code.
- Can doi chieu Order, OrderDetail, Customer, Product, User va CartItem voi project thuc te truoc khi build.
- Thanh toan chuyen khoan/COD moi chi duoc ghi nhan phuong thuc; chua tich hop cong thanh toan.
- Code khong co comment trong cac file ma nguon.
